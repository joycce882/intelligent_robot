#ifndef __FINGERUSE_H
#define __FINGERUSE_H



#define led1 PCout(13)

void Add_FR(void);  //¼ָ��
void press_FR(void);//ˢָ��
void Del_FR(void);  //ɾ��ָ��

#endif
